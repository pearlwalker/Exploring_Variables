# Exploring_Variables
Repository for IGME.201 assignment "Participation: Exploring Variables"
